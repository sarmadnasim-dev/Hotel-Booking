<?php
session_start();
include 'config/db.php';

$room_id = $_GET['room_id'];

if(isset($_POST['book'])) {
    $user_id = $_SESSION['user_id'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];

    mysqli_query($conn, "INSERT INTO bookings(user_id,room_id,check_in,check_out)
    VALUES('$user_id','$room_id','$check_in','$check_out')");

    echo "Booking Successful";
}
?>

<form method="POST">
    Check In <input type="date" name="check_in"><br>
    Check Out <input type="date" name="check_out"><br>
    <button name="book">Book Now</button>
</form>
