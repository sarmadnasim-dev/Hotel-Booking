<?php
$conn = mysqli_connect("localhost", "root", "", "hotel_booking");

if (!$conn) {
    die("Database Connection Failed");
}
?>
