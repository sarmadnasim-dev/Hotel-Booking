<?php
include 'config/db.php';
$result = mysqli_query($conn, "SELECT * FROM rooms");
?>

<h2>Available Rooms</h2>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
    <div>
        <h3><?php echo $row['room_name']; ?></h3>
        <p><?php echo $row['description']; ?></p>
        <p>Price: <?php echo $row['price']; ?></p>
        <a href="booking.php?room_id=<?php echo $row['id']; ?>">Book</a>
    </div>
<?php } ?>
