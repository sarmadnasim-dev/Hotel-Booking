<!DOCTYPE html>
<html>
<head>
    <title>Hotel Booking</title>
</head>
<body>

<h1>Hotel Booking System</h1>

<a href="rooms.php">View Rooms</a><br>
<a href="register.php">Register</a><br>
<a href="login.php">Login</a>

</body>
</html>
