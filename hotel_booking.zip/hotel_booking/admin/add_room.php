<?php
include '../config/db.php';

if(isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $desc = $_POST['desc'];

    mysqli_query($conn, "INSERT INTO rooms(room_name,price,description)
    VALUES('$name','$price','$desc')");
}
?>

<form method="POST">
    <input name="name" placeholder="Room Name"><br>
    <input name="price" placeholder="Price"><br>
    <textarea name="desc"></textarea><br>
    <button name="add">Add Room</button>
</form>
